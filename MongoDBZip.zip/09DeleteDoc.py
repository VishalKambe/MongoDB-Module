'''Write a program to accept ID, fetch the document from collection, 
copy it in another collection "outofstock" and delete the document 
from the "mobiles" collection
'''
from pymongo import MongoClient
try:
    client=MongoClient("mongodb+srv://Alibabadb:Alibaba.mango@cluster0.i4fzc.mongodb.net/shopping?retryWrites=true&w=majority")
    db=client["shopping"]
    coll=db["mobiles"]
    coll1=db["outofstock"]
    id=int(input("Enter ID to delete model  :"))
    qr={}
    qr["_id"]=id
    for doc in coll.find(qr):
        print(doc)
    coll1.insert_one(doc)
    print("%d id added to outofstock collection successfully...\n"%id)
    coll.delete_one(qr)
    print("%d id removes from mobile collection successfully...\n"%id)
except Exception as e:
    print("Error   :",e)
except Exception as e:
    print(e)
