'''Write a python program to take input from the user and add employee 
data as a document in the collection (ex. ID, company, model,
processor, screensize, ram, rom, connectivity, price, rating, etc.)
'''
from pymongo import MongoClient

try:
    id=int(input("Enter The Employee Id  :"))
    com=input("Enter Company Name  :")
    mod=input("Enter Model Name  :")
    pro=input("Enter Processor  :")
    scr=float(input("Enter The Screen Size  :"))
    ram=input("Enter The Ram  :")
    rom=input("Enter The Rom  :")
    con=input("Enter Connectivity  :")
    prc=float(input("Enter Model Price  :"))
    rat=float(input("Enter Model Rating  :"))


    dic={ }
    dic["_id"]=id
    dic["company"]=com
    dic["model"]=mod
    dic["processor"]=pro
    dic["screen"]=scr
    dic["ram"]=ram
    dic["rom"]=rom
    dic["connectivity"]=con
    dic["price"]=prc
    dic["rating"]=rat

    client=MongoClient("mongodb+srv://Alibabadb:Alibaba.mango@cluster0.i4fzc.mongodb.net/shopping?retryWrites=true&w=majority")
    db=client["shopping"]
    Coll=db["mobiles"] 

    Coll.insert_one(dic)
    print("Data Inserted Successfully....!")

except Exception as e:
    print("Please Enter Valid input :",e)
   

