''' Write a program to take ID as input, search and display the 
document with mobile information
'''
from pymongo import MongoClient

try:
    
    client=MongoClient("mongodb+srv://Alibabadb:Alibaba.mango@cluster0.i4fzc.mongodb.net/shopping?retryWrites=true&w=majority")
    db=client["shopping"]
    coll=db["mobiles"]


    num=int(input("Enter Empolyee's ID  :"))

    qr={ }
    qr["_id"]=num

    for doc in coll.find( ):
        print(doc)

except Exception as e:
    print("Error   :",e)
