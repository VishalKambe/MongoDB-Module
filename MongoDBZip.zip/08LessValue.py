''' Write a program to accept price and display all documents having 
price less than the input value
'''
try:
    from pymongo import MongoClient
    client=MongoClient("mongodb+srv://Alibabadb:Alibaba.mango@cluster0.i4fzc.mongodb.net/shopping?retryWrites=true&w=majority")
    db=client["shopping"]
    coll=db["mobiles"]
    prc=int(input("Enter Price  :"))
    qr={}
    qr["price"]=prc
    qr1={"price":{"$lte":prc}}
    for doc in coll.find(qr1):
        print(doc)

except Exception as e:
    print("Error",e)


