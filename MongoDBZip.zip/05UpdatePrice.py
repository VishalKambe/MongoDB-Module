'''Write a program to accept ID and new price of the mobile. Update 
the document with new price. Display the document after updating.
'''
from pymongo import MongoClient
try:
    id=int(input("Enter ID to Update Moblie Price  :"))
    dic={}
    dic["_id"]=id
    prc=int(input("Enter New Price  :"))
    ch={}
    ch["price"]=prc
    upd={"$set":ch}

    client=MongoClient("mongodb+srv://Alibabadb:Alibaba.mango@cluster0.i4fzc.mongodb.net/shopping?retryWrites=true&w=majority")
    db=client["shopping"]
    coll=db["mobiles"]
    coll.update_one(dic,upd)
    print("Price Updated...")

except Exception as e:
    print("Error   :",e)