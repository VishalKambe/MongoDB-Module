''' Write a program to show list of all documents from the collection
'''
try:
    from pymongo import MongoClient

    client=MongoClient("mongodb+srv://Alibabadb:Alibaba.mango@cluster0.i4fzc.mongodb.net/shopping?retryWrites=true&w=majority")
    db=client["shopping"]
    coll=db["mobiles"]

    for doc in coll.find():
        print(doc)

except Exception as e:
    print("Error   :",e)