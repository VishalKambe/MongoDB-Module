'''Write a program to take company as an input and display documents 
of all mobiles of the company
'''

from pymongo import MongoClient
try:

    client=MongoClient("mongodb+srv://Alibabadb:Alibaba.mango@cluster0.i4fzc.mongodb.net/shopping?retryWrites=true&w=majority")
    db=client["shopping"]
    coll=db["mobiles"]

    comp=input("Enter Company Name  :")
    dic={}
    dic['company']=comp
    print(dic)
    for doc in coll.find(dic):
        print(doc)

except Exception as e:
    print("Error   :",e)