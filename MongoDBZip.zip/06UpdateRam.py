'''Write a program to accept ID, ram and rom. Update the document 
with new ram and rom of the model. (memory size temp & permanent)
'''
from pymongo import MongoClient
try:
    id=int(input("Enter ID To Update Ram & Rom  :"))
    dic={}
    dic["_id"]=id
    ram=input("Enter Ram In GB  :")
    ch1={}
    ch1["ram"]=ram
    upd1={"$set":ch1}
    rom=input("Enter ROM In GB  :")
    ch2={}
    ch2["rom"]=rom
    upd2={"$set":ch2}
    client=MongoClient("mongodb+srv://Alibabadb:Alibaba.mango@cluster0.i4fzc.mongodb.net/shopping?retryWrites=true&w=majority")
    db=client["shopping"]
    coll=db["mobiles"]
    coll.update_one(dic,upd1)
    coll.update_one(dic,upd2)
    print("Price Updated...")

except Exception as e:
    print("Error   :",e)